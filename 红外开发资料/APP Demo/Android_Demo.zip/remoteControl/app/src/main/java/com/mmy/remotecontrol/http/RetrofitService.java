package com.mmy.remotecontrol.http;

/**
 * @创建者 lucas
 * @创建时间 2018/11/16 0016 10:20
 * @描述 TODO
 */
public class RetrofitService {

//    static Retrofit retrofit = new Retrofit.Builder()
//            .baseUrl(Constant.getBaseUrl()) //设置网络请求的Url地址
//            .addConverterFactory(GsonConverterFactory.create()) //设置数据解析器
//            .build();
//
//    public static Retrofit getService(){
//        return retrofit;
//    }

}
