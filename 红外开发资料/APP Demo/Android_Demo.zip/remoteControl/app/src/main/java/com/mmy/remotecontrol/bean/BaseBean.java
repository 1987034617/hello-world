package com.mmy.remotecontrol.bean;

/**
 * @创建者 lucas
 * @创建时间 2018/11/16 0016 10:42
 * @描述 TODO
 */
public class BaseBean {
    int code;
    String msg;
}
