package com.mmy.remotecontrol;

import org.litepal.LitePalApplication;
import org.litepal.tablemanager.Connector;

public class RemoteControlApp extends LitePalApplication {
    @Override
    public void onCreate() {
        super.onCreate();
        Connector.getDatabase();
    }
}
