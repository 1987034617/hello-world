package com.pilot.common.log.printer;

import com.pilot.common.log.bean.LogInfo;

public interface Printer {

	void print(LogInfo logInfo);

}
