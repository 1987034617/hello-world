package com.pilot.common.utils;

public class EliminateWarningUtils {

	@SuppressWarnings("unchecked")
	public static <T> T cast(Object obj) {
		return (T) obj;
	}

}
