//
//  HomeController.h
//  Demo
//
//  Created by 李静莹 on 2018/12/21.
//  Copyright © 2018年 LiJingYing. All rights reserved.
//

#import "BaseController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HomeController : BaseController

@end

NS_ASSUME_NONNULL_END
