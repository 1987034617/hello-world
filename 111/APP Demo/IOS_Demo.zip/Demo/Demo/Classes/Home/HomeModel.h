//
//  HomeModel.h
//  Demo
//
//  Created by 李静莹 on 2018/12/21.
//  Copyright © 2018年 LiJingYing. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeModel : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *device_name;
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) NSString *device_id;
@end

NS_ASSUME_NONNULL_END
