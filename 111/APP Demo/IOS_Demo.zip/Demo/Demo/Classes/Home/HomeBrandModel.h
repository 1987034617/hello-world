//
//  HomeBrandModel.h
//  Demo
//
//  Created by 李静莹 on 2018/12/25.
//  Copyright © 2018年 LiJingYing. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeBrandModel : NSObject
@property (nonatomic, strong) NSString *ID;
@property (nonatomic, strong) NSString *bn;
@end

NS_ASSUME_NONNULL_END
