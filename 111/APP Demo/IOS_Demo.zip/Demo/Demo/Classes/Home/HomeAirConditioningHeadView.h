//
//  HomeAirConditioningHeadView.h
//  Demo
//
//  Created by 李静莹 on 2018/12/26.
//  Copyright © 2018年 LiJingYing. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HomeAirConditioningHeadView : UIView
@property (weak, nonatomic) IBOutlet UILabel *modelLabel;
@property (weak, nonatomic) IBOutlet UILabel *fengsuLabel;
@property (weak, nonatomic) IBOutlet UILabel *fengxiangLabel;
@property (weak, nonatomic) IBOutlet UILabel *valueLabel;
@property (weak, nonatomic) IBOutlet UILabel *label;
@end

NS_ASSUME_NONNULL_END
